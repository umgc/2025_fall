<?php
defined('MOODLE_INTERNAL') || die();

$plugin->version = 2025100517;  // YYYYMMDDHH (Year Month Day 24-hr time).
$plugin->requires = 2022112800; // YYYYMMDDHH (The release version of Moodle 4.1).
$plugin->component = 'local_learninglens'; // Name of your plugin (used for diagnostics).
$plugin->maturity = MATURITY_ALPHA;
?>